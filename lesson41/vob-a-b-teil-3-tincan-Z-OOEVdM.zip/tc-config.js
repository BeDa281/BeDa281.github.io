/* Tin Can configuration */

//
// ActivityID that is sent for the statement's object
//
TC_COURSE_ID = "http://6JurcSSuZXn1j9x0cglFo6pCyDLJXEPY_rise"

//
// CourseName for the activity
//
TC_COURSE_NAME = {
  "en-US": "VOB A &amp; B - Teil 3"
};

//
// CourseDesc for the activity
//
TC_COURSE_DESC = {
  "en-US": "&lt;p&gt;In diesem Bereich finden Sie ein Quiz mit einigen Fragen. Sie m&amp;uuml;ssen 100% der Fragen richtig beantworten, um das Quiz abzuschlie&amp;szlig;en.&lt;/p&gt;&lt;p&gt;&lt;br&gt;&lt;/p&gt;&lt;p&gt;Sie k&amp;ouml;nnen das Quiz beliebig oft wiederholen.&lt;/p&gt;"
};
